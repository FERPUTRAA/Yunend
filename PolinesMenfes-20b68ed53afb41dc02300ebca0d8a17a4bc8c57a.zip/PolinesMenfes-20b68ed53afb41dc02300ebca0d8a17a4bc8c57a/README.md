<h1 align="center">
  Dicari Kontributor!!
</h1>

Bosen ngoding sendirian? Gabung sini! Kita rame-rame bikin project ini makin mantap. Diskusi dan kontribusi ditunggu banget!

## Bagaimana caranya?

Untuk member organization PDF
1. Clone repository ini
2. Buat branch baru dengan nama user
3. Commit dan push
4. Buat pull request


# Getting Started. Pake npm semua yaa, biar sama

```
npm install
```
```
npm install lucide-react
```
```
npx shadcn@latest init
```
```
npm install framer-motion --legacy-peer-deps
```
